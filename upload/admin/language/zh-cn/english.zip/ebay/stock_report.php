<?php
$_['lang_openbay']                      = 'OpenBay Pro';
$_['lang_page_title']                   = 'OpenBay Pro for eBay';
$_['lang_ebay']                         = 'eBay';
$_['lang_heading']                      = 'Stock report';
$_['lang_btn_return']                   = 'Return';
$_['lang_report_label']                 = 'Email report';
$_['lang_report_btn']                   = 'Request';
$_['lang_ajax_load_error']               = 'Sorry, could not connect';
$_['lang_ajax_load_sent']               = 'Request has been sent';
